var express = require('express');
var app = express();
var user = require('../model/user.js');
var category = require('../model/category.js');
var furniture = require('../model/furniture.js');
var verifyToken = require('../auth/verifyToken.js');

var bodyParser = require('body-parser');
var urlencodedParser = bodyParser.urlencoded({ extended: false });
app.use(bodyParser.json());// parse application/json
app.use(urlencodedParser); // parse application/x-www-form-urlencoded


app.get('/api/user/:userid', function (req, res) {
    var id = req.params.userid;

    user.getUser(id, function (err, result) {
        if (!err) {
            res.send(result);
        }else{
            res.status(500).send("Some error");
        }
    });

});

app.get('/api/user', function (req, res) {

    user.getAllUsers( function (err, result) {
        if (!err) {
            res.send(result);
        }
        else{
             console.log(result);

       res.status(500).send("Some error");
        }
    });

});

/**Middleware that checks for valid token */
app.post('/api/user', verifyToken, function (req, res) {

    var username = req.body.username;
    var email = req.body.email; 
    var role = req.body.role;
    var password = req.body.password;

    user.addUser(username, email, role, password, function (err, result) {
        if (!err) {
            console.log(result + ' record inserted');
            res.send(result + ' record inserted');
        } else{
            res.send(err.statusCode);

        }
    });

});

app.post('/api/login', verifyToken, function (req, res) {

    var username = req.body.username;
    var email = req.body.email; 
    var role = req.body.role;
    var password = req.body.password;


});

app.put('/api/user/:userid', function (req, res) {
       
    //implement your code    

    var id = req.params.userid;
    var email = req.body.email; 
    var password = req.body.password;

    user.updateUser(email, password, id, function (err, result) {
        if (!err) {
            console.log(result + ' record updated');
            res.send(result + ' record updated');
        } else{
            res.send(err.statusCode);

        }
    });

    
});

app.delete('/api/user/:userid', function (req, res) {
    
    var userid = req.params.userid;
    
    user.deleteUser(userid, function (err, result) {
        if (!err) {
        
            res.send(result + ' record deleted');
        }else{
            console.log(err);
         
            res.status(500).send("Some error");
 
        }
    });
 
});



app.get('/api/category', function (req, res) {
    
    category.getCategory( function (err, result) {
        if (!err) {
            res.send(result);
        }
        else{
            console.log(err);
                
            res.status(500).send("Some error");
             
         }
    });
    
});

app.get('/api/category/:catid/furniture', function (req, res) {
    
    //fill in your code

    var id = req.params.catid;

    furniture.getFurnitureByCat(id, function (err, result) {
        if (!err) {
            res.send(result);
        }else{
            res.status(500).send("Some error");
        }
    });
 
 });
 

module.exports = app
