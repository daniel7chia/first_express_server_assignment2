var express = require('express');
var app = express();
var user = require('../model/user2.js');
var category = require('../model/category2.js');
var verifyToken = require('../auth/verifyToken.js');

var bodyParser = require('body-parser');
var food = require('../model/food.js');
var urlencodedParser = bodyParser.urlencoded({ extended: false });
app.use(bodyParser.json()); // parse application/json
app.use(urlencodedParser); // parse application/x-www-form-urlencoded

//Assignment 2: CORS middleware library to enable web api access from all urls
var cors= require('cors');
app.options('*',cors()); // include before other routes
app.use(cors());

/*
var whitelist = ['http:// localhost:3001/user/'];

var corsOptions = {
  origin: function (origin, callback) {
    if (whitelist.indexOf(origin) !== -1) {
      callback(null, true);
    } else {
      callback(new Error('Not allowed by CORS'));
    }
  }
}
app.use(cors(corsOptions));
*/

app.get('/api/user/:userid', function (req, res) {
    var id = req.params.userid;

    user.getUser(id, function (err, result) {
        if (!err) {
            res.send(result);
        }else{
            res.status(500).send("Some error");
        }
    });

});

app.get('/api/user', function (req, res) {

    user.getAllUsers( function (err, result) {
        if (!err) {
            res.send(result);
        }
        else{
             console.log(result);

       res.status(500).send("Some error");
        }
    });

});

//Assignment 2: user must be authenticated as role admin and hold a valid JWT 
//in order to add food item

app.post('/api/food', verifyToken, function (req, res) {

    var name = req.body.name;
    var description = req.body.description; 
    var price = req.body.price;
    var stall = req.body.stall;
    var catid = req.body.catid;
    var role = req.role;

    if (role=="admin"){

    food.addFood(name, description, price, stall, catid, function (err, result) {
        if (!err) {
            console.log(result + ' record successfully inserted by admin');
            res.send(result + ' record successfully inserted by admin');
        } else{
            res.send(err.statusCode);

        }
    });
    
    }

    else {
        res.end(role + ' role is not permitted to add Food Item');
        console.log(role + ' role is not permitted to add Food Item')
    }

});


//Assignment 2: user must be authenticated as role admin and hold a valid JWT 
//in order to add category

app.post('/api/category', verifyToken, function (req, res) {

    var name = req.body.name;
    var description = req.body.description; 
    var role = req.role;

if (role=="admin"){

    category.addCategory(name, description, function (err, result) {
        if (!err) {
            console.log(role);
            console.log(result + ' record successfully inserted by admin');
            res.send(result + ' record successfully inserted by admin');
        } 

        else{
            res.send(err.statusCode);

        }
    });

}

else {
    res.end(role + ' role is not permitted to add Food Category');
    console.log(role + ' role is not permitted to add Food Category')
}

});


//Assignment 2: insert user Post method web api route ('/api/user')
//can only be called by authenticated users with a valid token (verifyToken)

app.post('/api/user', verifyToken, function (req, res) {

    var name = req.body.name;
    var email = req.body.email; 
    var role = req.body.role;
    var password = req.body.password;

    user.addUser(email,name,role,password,function(err,result){
        if (!err) {
            console.log(result + ' user inserted');
            res.send(result + ' user inserted');
        } else{
            res.send(err.statusCode);
        }
    })


});

//Assignment 1: Verify admin’s credentials using email and password 
//This function will return 1 representing success and 0 representing failure

app.post('/api/loginn',function(req,res){

    var email=req.body.email;
    var password=req.body.password;

    user.loginUser(email,password,function(err,result){
        if(!err){
            res.send("{\"result\":\""+result +"\"}");

        }else{
            res.status(500);
            res.send(err.statusCode);

        }

    });
});

// Assignment 2: Update food item; only Admin holding a valid JWT is allowed to perform this operation

app.put('/api/food/:foodid', verifyToken, function(req,res){

var id = req.params.foodid;
var name = req.body.name;
var description = req.body.description;
var price = req.body.price;
var stallname = req.body.stallname;
var catid = req.body.catid;
var role = req.role;

if (role=="admin"){

food.updateFood(name, description, price, stallname, catid, id, function(err, result){
    if (!err) {
        console.log(result + ' record successfully updated by admin');
        res.send(result + ' record successfully updated by admin');
    } else{
        res.send(err.statusCode);

    }

});

}

else{
    res.end(role + ' role is not permitted to update Food Item');
    console.log(role + ' role is not permitted to update Food Item')
}

});

// Assignment 2: Delete food item; only Admin holding a valid JWT is allowed to perform this operation

app.delete('/api/food/:foodid', verifyToken, function(req,res){

    var id = req.params.foodid;
    var role = req.role;

    if (role=="admin"){
        food.deleteFood(id, function(err,result){
            if (!err) {
                console.log(result + ' record successfully deleted by admin');
                res.send(result + ' record successfully deleted by admin');
            } else{
                res.send(err.statusCode);
        
            }
        });
    }

    else{
    res.end(role + ' role is not permitted to delete Food Item');
    console.log(role + ' role is not permitted to delete Food Item')
    }

});

    // Assignment 2: Delete category and 
    // cascade delete all the food items belonging to that category

app.delete('/api/category/:catid', verifyToken, function(req,res){

    var id = req.params.catid;
    var role = req.role;

    if (role=="admin"){
        category.deleteCategory(id, function(err,result){
            if (!err) {
                console.log(result + ' record successfully deleted by admin');
                res.send(result + ' record successfully deleted by admin');
            } else{
                res.send(err.statusCode);
        
            }
        });
    }

    else{
    res.end(role + ' role is not permitted to delete Category');
    console.log(role + ' role is not permitted to delete Category')
    }

});

app.put('/api/category/:catid', verifyToken, function(req,res){

    var id = req.params.catid;
    var name = req.body.name;
    var description = req.body.description;
    var role = req.role;

    if (role=="admin"){
    category.updateCategory(name, description, id, function(err,result){
        if (!err) {
            console.log(result + ' record successfully updated by admin');
            res.send(result + ' record successfully updated by admin');
        } else{
            res.send(err.statusCode);
    
        }
    });
    }

    else{
        res.end(role + ' role is not permitted to update Food Category');
        console.log(role + ' role is not permitted to update Food Category')
    }
});

app.put('/api/user/:userid', function (req, res) {
       
    //implement your code    

    var id = req.params.userid;
    var email = req.body.email; 
    var password = req.body.password;

    user.updateUser(email, password, id, function (err, result) {
        if (!err) {
            console.log(result + ' record updated');
            res.send(result + ' record updated');
        } else{
            res.send(err.statusCode);

        }
    });

    
});

app.delete('/api/user/:userid', function (req, res) {
    
    var userid = req.params.userid;
    
    user.deleteUser(userid, function (err, result) {
        if (!err) {
        
            res.send(result + ' record deleted');
        }else{
            console.log(err);
         
            res.status(500).send("Some error");
 
        }
    });
 
});



app.get('/api/category', function (req, res) {
    
    category.getCategory( function (err, result) {
        if (!err) {
            res.send(result);
        }
        else{
            console.log(err);
                
            res.status(500).send("Some error");
             
         }
    });
    
});

app.get('/api/food', function (req, res) {
    
    food.getFood( function (err, result) {
        if (!err) {
            res.send(result);
        }
        else{
            console.log(err);
                
            res.status(500).send("Some error");
             
         }
    });
    
});

app.get('/api/category/:catid/food', function (req, res) {
    
    //fill in your code

    var id = req.params.catid;

    food.getFoodByCat(id, function (err, result) {
        if (!err) {
            res.send(result);
        }else{
            res.status(500).send("Some error");
        }
    });
 
 });
 

module.exports = app
