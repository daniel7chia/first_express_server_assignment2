var express = require('express');
var serveStatic = require('serve-static');
var app = express();
var port=3001;
var hostname="localhost";
var app = require('./controller/app2.js');
//const http = require("http");

var server = app.listen(port, function () {

  console.log('Web App Hosted at http://localhost:%s',port);

});


  app.use(function(req, res, next) {//create our custom middleware
    console.log(req.url);
    console.log(req.method)
    console.log(req.path);    
    console.log(req.query.id);

    next();
  });
/*
  app.use(function(req, res, next) {
    console.log(req.url);
    console.log(req.method)
    console.log(req.path);    
    console.log(req.query.id);
    res.status(200);
    res.type(".html");
    res.end("<html><body>Using response object!</body></html>");
    //res.redirect("https://www.sp.edu.sg");//comment out if we just want to redirect

    //next();//since we are setting the whole response data, do not pass to the next middleware
  });
*/

  app.use(serveStatic(__dirname + '/public')); //apply middleware with app.use
  app.listen(port, hostname, () => {
    console.log(`Server started and accessible via http://${hostname}:${port}/`);
  });
