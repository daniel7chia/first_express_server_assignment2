var db=require('./databaseConfig.js');

var furnitureDB = {
    getFurnitureByCat: function (catid,callback) { 
        
        var conn = db.getConnection();

        conn.connect(function(err){

            if (err) {
                console.log(err);
                return callback(err,null); 
            }

            else{
                console.log("Connected!");

                var sql = 'SELECT * FROM furniture f WHERE cat_id = ?';

                conn.query(sql, [catid], function (err, result) {

                    conn.end();

                    if (err) {
                        console.log(err);
                        return callback(err,null);

                    } else {
                        console.log(result);
                        return callback(null, result);
                    }
                });

            }

        });   
    }

};

module.exports = furnitureDB
