const dbconnect = require('./databaseConfig2.js');
var db = require('./databaseConfig2.js');
var config=require('../config.js'); 
var jwt=require('jsonwebtoken');


var userDB = {
    getUser: function (userid, callback) {
        var conn = db.getConnection();

        conn.connect(function(err){

            if (err) {
                console.log(err);
                return callback(err,null); 
            }

            else{
                console.log("Connected!");

                var sql = 'SELECT * FROM user WHERE user_id = ?';

                conn.query(sql, [userid], function (err, result) {

                    conn.end();

                    if (err) {
                        console.log(err);
                        return callback(err,null);

                    } else {
                        console.log(result);
                        return callback(null, result);
                    }
                });

            }

        });
    },

    getAllUsers: function (callback) {

        var conn = db.getConnection();

        conn.connect(function(err){

            if (err) {
                console.log(err);
                return callback(err,null); 
            }

            else{
                console.log("Connected!");

                var sql = 'SELECT * FROM user';

                conn.query(sql, function (err, result) {

                    conn.end();

                    if (err) {
                        console.log(err);
                        return callback(err,null);

                    } else {
                        console.log(result);
                        return callback(null, result);
                    }
                });

            }

        });
    },

    addUser: function (username, email, role, password, callback) {

        var conn = db.getConnection();
        conn.connect(function (err) {
            if (err) {
                console.log(err);
                return callback(err,null);
            }
            else {
                console.log("Connected!");

                var sql = 'INSERT INTO user(name,email,role,password) values(?,?,?,?)';

                conn.query(sql, [username, email, role, password], function (err, result) {
                    conn.end();
                    
                    if (err) {
                        console.log(err);
                        return callback(err,null);
                        
                    } else {

                        console.log(result.affectedRows);
                        
                        return callback(null,result.affectedRows);

                    }
                });

            }

        });

    },

    updateUser: function (email,password,userid, callback) {

        var conn = db.getConnection(); 
        
        //The sql should be similar to var sql = 'Update user set email=?,password=? //where userid=?';
        //your code

        conn.connect(function(err){

            if (err) {
                console.log(err);
                return callback(err,null); 
            }

            else{
                console.log("Connected!");

                var sql = 'UPDATE user SET email=?,password=? WHERE user_id=?';

                conn.query(sql, [email,password,userid], function (err, result) {

                    conn.end();

                    if (err) {
                        console.log(err);
                        return callback(err,null);

                    } else {
                        console.log(result);
                        return callback(null, result);
                    }
                });

            }

        });


          },

          deleteUser: function (userid, callback) {
        
            var conn = db.getConnection();
            conn.connect(function (err) {
                if (err) {
                    console.log(err);
                    return callback(err,null);
                }
                else {    
                    console.log("Connected!");
            
                    var sql = 'Delete from user WHERE user_id=?';
            
                    conn.query(sql, [userid], function (err, result) {
                        conn.end();
                                
                        if (err) {
                            console.log(err);
                            return callback(err,null);
                                    
                        } else {
                                           
                            return callback(null,result.affectedRows);
            
                        }
                    });
            
                }        
            });  
            
        }, 

        //Assignment 1: Verify admin’s credentials using email and password 
        //This function will return 1 representing success and 0 representing failure

        // Assignment 2:
        //upon successful verification of the login credentials
        //use the jsonwebtoken library that contains a sign function, to 
        //generate a json web token to return to the caller of the webservice

        //Note: when using Postman, choose "Body", "x-www-form-urlencoded"

/*
        loginUser: function (email,password, callback) {
        
            var conn = db.getConnection();
            conn.connect(function (err) {
                if (err) {
                    console.log(err);
                    return callback(err,null);
                }
                else {
            
                    console.log("Connected!");
            
                    var sql = 'select * from user where email=? and password=?';
            
                    conn.query(sql, [email,password], function (err, result) {
                        conn.end();
                                
                        if (err) {
                            console.log(err);
                            return callback(err,null);
                                    
                        } else {
            
                            //console.log(config.key);
                            var token="";
                            if(result.length==1){
                                token=jwt.sign({id:result[0].userid,role:result[0].role},config.key,{
    
                                    expiresIn:86400//expires in 24 hrs
                                });
            
                            }
                                    
                            return callback(null,token);
            
                        }
                    });
            
                }
          
            });


            
        }
    
    */


        //Assignment 1: Verify admin’s credentials using email and password 
        //This function will return 1 representing success and 0 representing failure
        //Note: when using Postman, choose "Body", "x-www-form-urlencoded"

        // Assignment 2:
        //upon successful verification of the login credentials
        //use the jsonwebtoken library that contains a sign function, to 
        //generate a json web token to return to the caller of the webservice

        loginUser: function (email,password, callback) {
        
            var conn = db.getConnection();
            conn.connect(function (err) {
                if (err) {
                    console.log(err);
                    return callback(err,null);
                }
                else {
                    console.log("Connected!");
            
                    var sql = 'SELECT * FROM user WHERE email=? and password=?';
            
                    conn.query(sql, [email,password], function (err, result) {
                        conn.end();
                                
                        if (err) {
                            console.log(err);
                            return callback(err,null);
                                    
                        } else {
            
                            var msg="{\"result\":\""+result.length+"\"}";       
                            console.log(msg);        
                            //console.log(config.key);
                            var token="";
                                if(result.length==1)
                                {//token expires in 24 hrs
                                 token=jwt.sign({id:result[0].userid,role:result[0].role},config.key,{expiresIn:86400});
                                 }
                            //return callback(null, msg);
                            return callback(null, token);
                        }
                    });
            
                }
            
            });
        }    
        
}

module.exports=userDB;
