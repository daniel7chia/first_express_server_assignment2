var db=require('./databaseConfig2.js');

var foodDB = {

//Assignment 1: Retrieve food products based on ii) categoryid, sorted in ascending price. 

    getFoodByCat: function (catid,callback) { 
        
        var conn = db.getConnection();

        conn.connect(function(err){

            if (err) {
                console.log(err);
                return callback(err,null); 
            }

            else{
                console.log("Connected!");

                var sql = 'SELECT * FROM food_item f WHERE category_id = ? or stall_name LIKE ? ORDER BY price ASC';
                //var sql = 'SELECT * FROM food_item f WHERE category_id = ? ORDER BY price ASC';

                conn.query(sql, [catid, "%" + stallstring + "%"], function (err, result) {

                    conn.end();

                    if (err) {
                        console.log(err);
                        return callback(err,null);

                    } else {
                        console.log(result);
                        return callback(null, result);
                    }
                });
            }
        });   
    },

// Assignment 1: Retrieve all food menu items

    getFood: function (callback) { 

        var conn = db.getConnection();
        conn.connect(function (err) {
            if (err) {           
                console.log(err);
                return callback(err,null);
            }
            else{
               
                var sql = 'SELECT * FROM food_item';
                
                conn.query(sql,function (err,result) {
                      if (err){
                        
                        return callback(err,null);
                           
                      }else{
                                            
                        return callback(null,result);
        
                      }
                      conn.end(); 
                });

            }

        });  
        
    },

// Assignment 1: Add new food menu item
// Note: when using Postman, choose "Body", "x-www-form-urlencoded"

    addFood: function (name, description, price, stall, catid, callback) {

        var conn = db.getConnection();
        conn.connect(function (err) {
            if (err) {
                console.log(err);
                return callback(err,null);
            }
            else {
                console.log("Connected!");

                var sql = 'INSERT INTO food_item(name,description,price,stall_name,category_id) values(?,?,?,?,?)';

                conn.query(sql, [name, description, price, stall, catid], function (err, result) {
                    conn.end();
                    
                    if (err) {
                        console.log(err);
                        return callback(err,null);
                        
                    } else {

                        console.log(result.affectedRows);
                        
                        return callback(null,result.affectedRows);

                    }
                });

            }

        });

    },

    // Assignment 2: Update food item

    updateFood: function (name, description, price, stallname, catid, id, callback) {

        var conn = db.getConnection(); 

        conn.connect(function(err){

            if (err) {
                console.log(err);
                return callback(err,null); 
            }

            else{
                console.log("Connected!");

                var sql = 'UPDATE food_item SET name=?,description=?,price=?,stall_name=?,category_id=? WHERE food_id=?';

                conn.query(sql, [name, description, price, stallname, catid, id], function (err, result) {

                    conn.end();

                    if (err) {
                        console.log(err);
                        return callback(err,null);

                    } else {
                        console.log(result);
                        return callback(null, result);
                    }
                });
            }
        });
    },

    // Assignment 2: Delete food item

    deleteFood: function (id, callback) {
        
        var conn = db.getConnection();
        conn.connect(function (err) {
            if (err) {
                console.log(err);
                return callback(err,null);
            }
            else {    
                console.log("Connected!");
        
                var sql = 'Delete from food_item WHERE food_id=?';
        
                conn.query(sql, [id], function (err, result) {
                    conn.end();
                            
                    if (err) {
                        console.log(err);
                        return callback(err,null);
                                
                    } else {           
                        return callback(null,result.affectedRows);
                    }
                });
            }        
        });  
    }, 

};

module.exports = foodDB
