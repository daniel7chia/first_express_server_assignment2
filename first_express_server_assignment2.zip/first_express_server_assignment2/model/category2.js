var db=require('./databaseConfig2.js');

var categoryDB = {

    // Assignment 1: Retrieve all categories

    getCategory: function (callback) { 

        var conn = db.getConnection();
        conn.connect(function (err) {
            if (err) {           
                console.log(err);
                return callback(err,null);
            }
            else{
               
                var sql = 'SELECT * FROM category';
                
                conn.query(sql,function (err,result) {
                      if (err){
                        
                        return callback(err,null);
                           
                      }else{
                                            
                        return callback(null,result);
        
                      }
                      conn.end(); 
                });

            }

        });  
        
    },

    // Assignment 1: Add new category
    //Note: when using Postman, choose "Body", "x-www-form-urlencoded"

    addCategory: function (name, description, callback) {

        var conn = db.getConnection();
        conn.connect(function (err) {
            if (err) {
                console.log(err);
                return callback(err,null);
            }
            else {
                console.log("Connected!");

                var sql = 'INSERT INTO category(name,description) values(?,?)';

                conn.query(sql, [name, description], function (err, result) {
                    conn.end();
                    
                    if (err) {
                        console.log(err);
                        return callback(err,null);
                        
                    } else {

                        console.log(result.affectedRows);
                        return callback(null,result.affectedRows);
                    }
                });
            }
        });
    },

    updateCategory: function (name, description, id, callback){

        var conn = db.getConnection();
        conn.connect(function(err){
            if (err){
                console.log(err);
                return callback(err,null);
            }
            else {
                console.log("Connected");
                var sql = 'UPDATE category SET name=?,description=? WHERE category_id=?';

                conn.query(sql, [name, description, id], function (err,result){
                    conn.end();

                    if (err) {
                        console.log(err);
                        return callback(err,null);

                    } else {
                        console.log(result);
                        return callback(null, result);
                    }
                });
            }
        });
    },

    // Assignment 2: Delete category and 
    // cascade delete all the food items belonging to that category

    deleteCategory: function (id, callback) {
        
        var conn = db.getConnection();
        conn.connect(function (err) {
            if (err) {
                console.log(err);
                return callback(err,null);
            }
            else {    
                console.log("Connected!");
        
                var sql = 'Delete from category WHERE category_id=?';
        
                conn.query(sql, [id], function (err, result) {
                    conn.end();
                            
                    if (err) {
                        console.log(err);
                        return callback(err,null);
                                
                    } else {           
                        return callback(null,result.affectedRows);
                    }
                });
            }        
        });  
    }, 

 
};

module.exports = categoryDB
