const dbconnect = require('./databaseConfig.js');
var db = require('./databaseConfig.js');
var config=require('../config.js'); 
var jwt=require('jsonwebtoken');


var userDB = {
    getUser: function (userid, callback) {
        var conn = db.getConnection();

        conn.connect(function(err){

            if (err) {
                console.log(err);
                return callback(err,null); 
            }

            else{
                console.log("Connected!");

                var sql = 'SELECT * FROM user WHERE userid = ?';

                conn.query(sql, [userid], function (err, result) {

                    conn.end();

                    if (err) {
                        console.log(err);
                        return callback(err,null);

                    } else {
                        console.log(result);
                        return callback(null, result);
                    }
                });

            }

        });
    },

    getAllUsers: function (callback) {

        var conn = db.getConnection();

        conn.connect(function(err){

            if (err) {
                console.log(err);
                return callback(err,null); 
            }

            else{
                console.log("Connected!");

                var sql = 'SELECT * FROM user';

                conn.query(sql, function (err, result) {

                    conn.end();

                    if (err) {
                        console.log(err);
                        return callback(err,null);

                    } else {
                        console.log(result);
                        return callback(null, result);
                    }
                });

            }

        });
    },

    addUser: function (username, email, role, password, callback) {

        var conn = db.getConnection();
        conn.connect(function (err) {
            if (err) {
                console.log(err);
                return callback(err,null);
            }
            else {
                console.log("Connected!");

                var sql = 'INSERT INTO user(username,email,role,password) values(?,?,?,?)';

                conn.query(sql, [username, email, role, password], function (err, result) {
                    conn.end();
                    
                    if (err) {
                        console.log(err);
                        return callback(err,null);
                        
                    } else {

                        console.log(result.affectedRows);
                        
                        return callback(null,result.affectedRows);

                    }
                });

            }

        });

    },

    updateUser: function (email,password,userid, callback) {

        var conn = db.getConnection(); 
        
        //The sql should be similar to var sql = 'Update user set email=?,password=? //where userid=?';
        //your code

        conn.connect(function(err){

            if (err) {
                console.log(err);
                return callback(err,null); 
            }

            else{
                console.log("Connected!");

                var sql = 'UPDATE user SET email=?,password=? WHERE userid=?';

                conn.query(sql, [email,password,userid], function (err, result) {

                    conn.end();

                    if (err) {
                        console.log(err);
                        return callback(err,null);

                    } else {
                        console.log(result);
                        return callback(null, result);
                    }
                });

            }

        });


          },

          deleteUser: function (userid, callback) {
        
            var conn = db.getConnection();
            conn.connect(function (err) {
                if (err) {
                    console.log(err);
                    return callback(err,null);
                }
                else {    
                    console.log("Connected!");
            
                    var sql = 'Delete from user WHERE userid=?';
            
                    conn.query(sql, [userid], function (err, result) {
                        conn.end();
                                
                        if (err) {
                            console.log(err);
                            return callback(err,null);
                                    
                        } else {
                                           
                            return callback(null,result.affectedRows);
            
                        }
                    });
            
                }        
            });  
            
        }, 


        loginUser: function (email,password, callback) {
        
            var conn = db.getConnection();
            conn.connect(function (err) {
                if (err) {
                    console.log(err);
                    return callback(err,null);
                }
                else {
            
                    console.log("Connected!");
            
                    var sql = 'select * from user where email=? and password=?';
            
                    conn.query(sql, [email,password], function (err, result) {
                        conn.end();
                                
                        if (err) {
                            console.log(err);
                            return callback(err,null);
                                    
                        } else {
            
                            //console.log(config.key);
                            var token="";
                            if(result.length==1){
                                token=jwt.sign({id:result[0].userid,role:result[0].role},config.key,{
    
                                    expiresIn:86400//expires in 24 hrs
                                });
            
                            }
                                    
                            return callback(null,token);
            
                        }
                    });
            
                }
          
            });
        }
    
    
        
}

module.exports=userDB;
