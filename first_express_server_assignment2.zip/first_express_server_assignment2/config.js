var secret='abc123xyz321'; //your own secret key
module.exports.key=secret;
